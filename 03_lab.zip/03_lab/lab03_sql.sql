
SELECT DATE_TRUNC('month', p.payment_date) AS "Месяц",
		s.store_id AS "Магазин",
		SUM(p.amount) AS "Доход",
		CASE 
  			WHEN SUM(p.amount) > 5000 THEN 'высокая выручка'
   			WHEN SUM(p.amount) > 2000  THEN 'средняя выручка'
   			ELSE 'низкая выручка'
		END AS "Выручка",

		SUM(SUM(p.amount)) OVER (
   		PARTITION BY DATE_TRUNC('month', p.payment_date)) AS "Общий доход по месяцам",
		ROUND(
		100*((SUM(p.amount))/SUM(SUM(p.amount)) OVER (
		PARTITION BY DATE_TRUNC('month', p.payment_date))),
		2) AS "Доля от всей выручки"

FROM payment p
JOIN staff st ON p.staff_id = st.staff_id
JOIN store s ON st.store_id = s.store_id
GROUP BY s.store_id, DATE_TRUNC('month', p.payment_date)
ORDER BY "Месяц"
;
